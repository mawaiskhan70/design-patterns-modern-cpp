#include "andspecification.h"
